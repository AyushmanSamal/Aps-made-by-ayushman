import random
from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        self.w = None
        Dialog.setObjectName("Dialog")
        Dialog.resize(983, 852)
        self.Computer = QtWidgets.QLabel(Dialog)
        self.Computer.setGeometry(QtCore.QRect(60, 90, 261, 261))
        self.Computer.setText("")
        self.Computer.setScaledContents(True)
        self.Computer.setObjectName("Computer")
        self.ComputerT = QtWidgets.QLabel(Dialog)
        self.ComputerT.setGeometry(QtCore.QRect(60, 90, 261, 261))
        self.ComputerT.setText("")
        self.ComputerT.setScaledContents(True)
        self.ComputerT.setObjectName("ComputerT")
        self.Player = QtWidgets.QLabel(Dialog)
        self.Player.setGeometry(QtCore.QRect(620, 90, 261, 261))
        self.Player.setText("")
        self.Player.setScaledContents(True)
        self.Player.setObjectName("Player")
        self.rock = QtWidgets.QRadioButton(Dialog)
        self.rock.setGeometry(QtCore.QRect(670, 450, 141, 61))
        self.rock.setChecked(False)
        self.rock.setAutoRepeatInterval(109)
        self.rock.setObjectName("rock")
        self.paper = QtWidgets.QRadioButton(Dialog)
        self.paper.setGeometry(QtCore.QRect(670, 490, 141, 61))
        self.paper.setChecked(False)
        self.paper.setAutoRepeatInterval(109)
        self.paper.setObjectName("paper")
        self.scissor = QtWidgets.QRadioButton(Dialog)
        self.scissor.setGeometry(QtCore.QRect(670, 530, 141, 61))
        self.scissor.setChecked(False)
        self.scissor.setAutoRepeatInterval(109)
        self.scissor.setObjectName("scissor")
        self.label = QtWidgets.QLabel(Dialog)
        self.label.setGeometry(QtCore.QRect(320, 40, 271, 91))
        font = QtGui.QFont()
        font.setPointSize(24)
        self.label.setFont(font)
        self.label.setObjectName("label")
        self.label.setText("")

        self.rock.clicked.connect(self.set_rock)
        self.paper.clicked.connect(self.set_paper)
        self.scissor.clicked.connect(self.set_scissor)

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)


    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.rock.setText(_translate("Dialog", "Rock"))
        self.paper.setText(_translate("Dialog", "Paper"))
        self.scissor.setText(_translate("Dialog", "Scissor"))

    def play(self, playerSelected:int):
        list = [1,2,3]
        a = random.choice(list)
        #print(a)
        selected = 0
        if a == 1:
            self.Computer.setPixmap(QtGui.QPixmap("stone.jpeg"))
            selected = 1
        elif a == 2:
            self.Computer.setPixmap(QtGui.QPixmap("paper.jpeg"))
            selected = 2
        else:
            self.Computer.setPixmap(QtGui.QPixmap("scissor.png"))
            selected = 3
        
        if selected == 1:
            if playerSelected == 3:
                self.label.setText("Computer Won")
                self.paper.hide()
                self.scissor.hide()
                self.rock.hide()
        
        if selected == 1:
            if playerSelected == 2:
                self.label.setText("Player Won")
                self.paper.hide()
                self.scissor.hide()
                self.rock.hide()

        if selected == 1:
            if playerSelected == 1:
                self.label.setText("Tie")

        if selected == 2:
            if playerSelected == 1:
                self.label.setText("Computer Won")
                self.paper.hide()
                self.scissor.hide()
                self.rock.hide()

        if selected == 2:
            if playerSelected == 2:
                self.label.setText("Tie")
                

        if selected == 2:
            if playerSelected == 3:
                self.label.setText("Player Won")
                self.paper.hide()
                self.scissor.hide()
                self.rock.hide()

        if selected == 3:
            if playerSelected == 3:
                self.label.setText("Tie")

        if selected == 3:
            if playerSelected == 1:
                self.label.setText("Player Won")
                self.paper.hide()
                self.scissor.hide()
                self.rock.hide()

        if selected == 3:
            if playerSelected == 2:
                self.label.setText("Computer Won")
                self.paper.hide()
                self.scissor.hide()
                self.rock.hide()


    def set_rock(self):
        self.Player.setPixmap(QtGui.QPixmap("stone.jpeg"))
        self.play(1)

    def set_paper(self):
        self.Player.setPixmap(QtGui.QPixmap("paper.jpeg"))
        self.play(2)

    def set_scissor(self):
        self.Player.setPixmap(QtGui.QPixmap("scissor.png"))
        self.play(3)

        

if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())
